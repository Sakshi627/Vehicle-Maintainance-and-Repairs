package com.app.pojos;

public enum ServiceType {
	PAID,FREE
}
